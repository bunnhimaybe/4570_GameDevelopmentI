# Top Shop
A time management strategy game where you manage a clothing store.  

Author: Nhi Pham  
Course: Game Development I  
Semester: 24 Fall  
Professor: Ben Samuel  
Assignment: Project 1  

# How to Install

Extract the zip file and launch the **TopShop.exe** file inside.
Click play to start the game!

# How to Play

If a customer sees something they like on the rack, they'll pay you for it!
If what they want isn't there, they'll leave and you won't earn any money. 
Click on the item on display to get it from the stockroom and restock the racks!

# Goals

Earn money and beat your high score!

# Credits

Original Character Sprites: Piano no Renshuu
https://piano-no-renshu.itch.io/top-down-character-sprites 

Music: Matthew Pablo ("Shake and Bake") 
https://opengameart.org/content/shake-and-bake